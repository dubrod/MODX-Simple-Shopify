# Simple Shopify for MODX 1.2.0
 - You must create a backup chunk *product-cache* with the products.json feed in it so broken cUrl has a backup.
 - Altered Snippet to get chunk backup if feed is empty.

# Simple Shopify for MODX 1.0.1
 - changed quantity input type to "number"
 - added a button to "empty the cart" if anything ever gets stuck
 - added my table CSS

# Simple Shopify for MODX 1.0.0
 - Initial Build
