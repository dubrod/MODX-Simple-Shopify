# Simple Shopify for MODX 1.0.1
 - changed quantity input type to "number"
 - added a button to "empty the cart" if anything ever gets stuck
 - added my table CSS
 
# Simple Shopify for MODX 1.0.0
 - Initial Build
