# MODX-Simple-Shopify
KnockoutJS Powered, drop-in package to display your Shopify Products Feed with a Cart
