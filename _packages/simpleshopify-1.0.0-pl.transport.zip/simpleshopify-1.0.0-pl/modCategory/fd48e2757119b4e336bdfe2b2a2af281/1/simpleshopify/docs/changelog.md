# Simple Shopify for MODX 1.0.0
 - Initial Build
